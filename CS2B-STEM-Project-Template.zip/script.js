/*
 You can change anything in these files--HTML tags, CSS styles, JavaScript functions, etc. 
 Do what you need to make it suitable for your STEM problem.

 The getInput function will take user input from the page. 
 You should call your functions from inside the getInput function.

 The writeOutput function will write some given text to the output span on the page. 
 You can call this function from your code and give it your result.
*/

// This function will get the text entered into the "input" text field.
// Then it calls another function with the input as an argument.
function getInput() {
  let inputField = document.querySelector("#input1");
  let input = inputField.value;
  let inputField2 = document.querySelector("#input2");
  let input2 = inputField2.value;
  let inputField3 = document.querySelector("#input3");
  let input3 = inputField3.value;
  let inputField4 = document.querySelector("#input4");
  let input4 = inputField4.value;
  let inputField5 = document.querySelector("#input5");
  let input5 = inputField5.value;
  let inputField6 = document.querySelector("#input6");
  let input6 = inputField6.value;
  let inputField7 = document.querySelector("#input7");
  let input7 = inputField7.value;
  let inputField8 = document.querySelector("#input8");
  let input8 = inputField8.value;
  let inputField9 = document.querySelector("#input9");
  let input9 = inputField9.value;
  let poop = String.fromCodePoint(0x1f4a9);

  // do something with the input
  let answer = (input * ((input5 * input9) - (input6 * input8))) - (input2 * ((input4 * input9) - (input6 * input7))) +(input3 * ((input4 * input8) - (input5 * input7)));
  if (answer == 0){
  writeOutput(poop)
} else{
   writeOutput(answer)
}; 
}

// This function will write some text to the output span on the page.

function writeOutput(text) {
  let outputSpan = document.querySelector("#output1");
  outputSpan.textContent = text;
}




document.querySelector("#buttonGo").addEventListener("click", getInput);